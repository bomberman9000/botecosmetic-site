#!/bin/bash

# Скрипт для исправления проблем с деплоем
# Выполните на сервере: ssh root@144.31.64.130, затем скопируйте и выполните эти команды

set -e

APP_DIR="/var/www/bote-site"
cd $APP_DIR

echo "🔍 Диагностика проблем..."

# 1. Проверяем Node.js
echo "1. Проверяю Node.js..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js не установлен. Устанавливаю..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
else
    echo "✅ Node.js: $(node --version)"
fi

# 2. Проверяем npm
echo "2. Проверяю npm..."
if ! command -v npm &> /dev/null; then
    echo "❌ npm не установлен"
    exit 1
else
    echo "✅ npm: $(npm --version)"
fi

# 3. Проверяем PM2
echo "3. Проверяю PM2..."
if ! command -v pm2 &> /dev/null; then
    echo "❌ PM2 не установлен. Устанавливаю..."
    npm install -g pm2
else
    echo "✅ PM2 установлен"
fi

# 4. Проверяем файлы проекта
echo "4. Проверяю файлы проекта..."
if [ ! -f "package.json" ]; then
    echo "❌ package.json не найден! Проверьте путь к проекту."
    exit 1
fi
echo "✅ Файлы проекта на месте"

# 5. Устанавливаем зависимости
echo "5. Устанавливаю зависимости..."
npm install --production

# 6. Собираем проект
echo "6. Собираю проект..."
npm run build

# 7. Останавливаем старое приложение
echo "7. Останавливаю старое приложение..."
pm2 delete bote-site 2>/dev/null || true

# 8. Запускаем приложение
echo "8. Запускаю приложение..."
pm2 start npm --name "bote-site" -- start

# 9. Сохраняем конфигурацию
pm2 save

# 10. Проверяем статус
echo ""
echo "📊 Статус приложения:"
pm2 list

echo ""
echo "📝 Последние логи:"
pm2 logs bote-site --lines 20 --nostream

echo ""
echo "✅ Готово! Проверьте работу:"
echo "   http://144.31.64.130:3001"
echo ""
echo "Если не работает, проверьте файрвол:"
echo "   ufw allow 3001/tcp"
echo "   или"
echo "   firewall-cmd --permanent --add-port=3001/tcp && firewall-cmd --reload"



