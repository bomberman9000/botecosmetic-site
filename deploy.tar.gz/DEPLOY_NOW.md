# 🚀 Инструкция по деплою на VPS

Архив `deploy.tar.gz` уже создан и готов к деплою.

## Шаг 1: Скопируйте архив на сервер

Выполните в терминале (потребуется пароль):

```bash
cd /Users/mac/.cursor/worktrees/1/vbg/bote-site
scp deploy.tar.gz root@144.31.64.130:/tmp/
```

## Шаг 2: Подключитесь к серверу

```bash
ssh root@144.31.64.130
```

## Шаг 3: На сервере выполните команды

Скопируйте и выполните все команды по порядку:

```bash
# Переходим в директорию проекта
mkdir -p /var/www/bote-site
cd /var/www/bote-site

# Распаковываем архив
tar -xzf /tmp/deploy.tar.gz
rm /tmp/deploy.tar.gz

# Проверяем Node.js (устанавливаем если нет)
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
fi

# Устанавливаем PM2 (если нет)
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
fi

# Устанавливаем зависимости (БЕЗ --production, так как нужны dev-зависимости для сборки)
npm install

# Собираем проект
npm run build

# Создаем PM2 конфигурацию
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'bote-site',
    script: 'node_modules/next/dist/bin/next',
    args: 'start -p 3001',
    cwd: '/var/www/bote-site',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3001
    }
  }]
}
EOF

# Останавливаем старое приложение (если есть)
pm2 delete bote-site 2>/dev/null || true

# Запускаем приложение
pm2 start ecosystem.config.js

# Сохраняем конфигурацию PM2
pm2 save

# Настраиваем автозапуск (выполните команду, которую покажет pm2 startup)
pm2 startup
```

## Шаг 4: Проверка

После выполнения команд проверьте:

```bash
# Проверка статуса
pm2 list

# Проверка логов
pm2 logs bote-site --lines 50

# Проверка порта
netstat -tlnp | grep 3001
```

## Готово! 🎉

Сайт должен быть доступен по адресу: `http://144.31.64.130:3001`

## Если что-то не работает:

```bash
# Перезапустить
pm2 restart bote-site

# Посмотреть логи
pm2 logs bote-site

# Пересобрать проект
cd /var/www/bote-site
npm run build
pm2 restart bote-site
```

