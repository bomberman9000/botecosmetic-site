# 🚀 Простая инструкция по деплою

## ⚠️ ВАЖНО: Вы должны быть на СЕРВЕРЕ через SSH!

Если вы видите ошибки про `pm2: command not found` - значит вы выполняете команды локально на своём компьютере, а не на сервере!

## Шаг 1: Скопируйте архив (на вашем компьютере, в НОВОМ терминале)

Откройте новый терминал на вашем Mac и выполните:

```bash
cd /Users/mac/.cursor/worktrees/1/vbg/bote-site
scp deploy.tar.gz root@144.31.64.130:/tmp/
```

Введите пароль от сервера.

## Шаг 2: Подключитесь к серверу

```bash
ssh root@144.31.64.130
```

## Шаг 3: На СЕРВЕРЕ выполните эти команды (копируйте по одной):

```bash
# 1. Переходим в директорию
mkdir -p /var/www/bote-site
cd /var/www/bote-site

# 2. Распаковываем архив
tar -xzf /tmp/deploy.tar.gz
rm /tmp/deploy.tar.gz

# 3. Устанавливаем ВСЕ зависимости (включая dev-зависимости для сборки)
npm install

# 4. Собираем проект
npm run build

# 5. Останавливаем старое приложение (если есть)
pm2 delete bote-site 2>/dev/null || true

# 6. Запускаем приложение
pm2 start npm --name "bote-site" -- start
pm2 save

# 7. Проверяем статус
pm2 list
```

## ✅ Готово!

Сайт будет доступен по адресу: `http://144.31.64.130:3001`

---
**Если PM2 не установлен на сервере, сначала установите его:**

```bash
npm install -g pm2
```

**Если Node.js не установлен:**

```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt-get install -y nodejs
```



