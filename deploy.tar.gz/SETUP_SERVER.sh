#!/bin/bash

# Команды для выполнения на сервере
# Скопируйте и выполните эти команды по порядку

echo "🔧 Начинаю настройку сервера..."

# 1. Проверяем и устанавливаем Node.js (если нужно)
if ! command -v node &> /dev/null; then
    echo "📦 Устанавливаю Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get update
    apt-get install -y nodejs
else
    echo "✅ Node.js уже установлен: $(node --version)"
fi

# 2. Устанавливаем PM2
echo "📦 Устанавливаю PM2..."
npm install -g pm2

# 3. Переходим в директорию проекта
cd /var/www/bote-site || {
    echo "❌ Директория /var/www/bote-site не найдена!"
    echo "Создаю директорию..."
    mkdir -p /var/www/bote-site
    echo "Распакуйте архив: tar -xzf /tmp/deploy.tar.gz"
    exit 1
}

# 4. Устанавливаем зависимости
echo "📦 Устанавливаю зависимости..."
npm install --production

# 5. Собираем проект
echo "🔨 Собираю проект..."
npm run build

# 6. Останавливаем старое приложение (если есть)
pm2 delete bote-site 2>/dev/null || true

# 7. Запускаем приложение
echo "🚀 Запускаю приложение..."
pm2 start npm --name "bote-site" -- start

# 8. Сохраняем конфигурацию PM2
pm2 save

# 9. Настраиваем автозапуск
pm2 startup

# 10. Настраиваем файрвол (проверяем какая система)
if command -v ufw &> /dev/null; then
    echo "🔥 Настраиваю UFW..."
    ufw allow 3001/tcp
elif command -v firewall-cmd &> /dev/null; then
    echo "🔥 Настраиваю firewalld..."
    firewall-cmd --permanent --add-port=3001/tcp
    firewall-cmd --reload
else
    echo "⚠️  Файрвол не найден. Настройте порт 3001 вручную в iptables"
fi

# 11. Показываем статус
echo ""
echo "✅ Настройка завершена!"
echo ""
echo "📊 Статус приложения:"
pm2 list

echo ""
echo "📝 Логи (последние 20 строк):"
pm2 logs bote-site --lines 20 --nostream

echo ""
echo "🌐 Проверьте работу:"
echo "   curl http://localhost:3001"
echo "   или в браузере: http://144.31.64.130:3001"



